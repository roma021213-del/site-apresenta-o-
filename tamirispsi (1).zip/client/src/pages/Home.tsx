import { useState } from "react";
import {
  ArrowDown,
  ArrowUpRight,
  Brain,
  CalendarDays,
  Check,
  ChevronDown,
  CircleUserRound,
  Clock3,
  Globe2,
  Heart,
  HeartHandshake,
  Instagram,
  Menu,
  MessageCircle,
  MoveRight,
  Phone,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Video,
  X,
} from "lucide-react";

const instagramUrl =
  "https://www.instagram.com/tamiris.psico?dlrf=MWZuaW1sbXJmbXJydw==";
const whatsappUrl = "https://wa.me/message/R7IFRNRFKHMND1";
const portraitUrl = "/manus-storage/173981_30b7a3fd.jpg";
const logoUrl = "/manus-storage/logo-round_ddfbd2d1.png";

const focusAreas = [
  {
    number: "01",
    title: "ANSIEDADE E PENSAMENTOS ACELERADOS",
    text: "Preocupações frequentes, insegurança, excesso de pensamentos e dificuldade para relaxar ou desacelerar a mente.",
    icon: Brain,
  },
  {
    number: "02",
    title: "DEPRESSÃO E DESÂNIMO",
    text: "Tristeza persistente, falta de motivação, perda de interesse por atividades e dificuldades para lidar com a rotina.",
    icon: Heart,
  },
  {
    number: "03",
    title: "PROCRASTINAÇÃO E AUTOCOBRANÇA",
    text: "Dificuldade para começar ou concluir tarefas, adiamento constante de atividades e cobranças excessivas consigo mesmo.",
    icon: Clock3,
  },
  {
    number: "04",
    title: "AUTOESTIMA E AUTOCONHECIMENTO",
    text: "Insegurança, autocrítica, dificuldade de reconhecer suas qualidades e de compreender as próprias necessidades.",
    icon: CircleUserRound,
  },
  {
    number: "05",
    title: "RELACIONAMENTOS E LIMITES",
    text: "Conflitos nos relacionamentos, dificuldades de comunicação, vínculos que geram sofrimento e desafios para estabelecer limites.",
    icon: HeartHandshake,
  },
];

const faqs = [
  {
    question: "Preciso morar na mesma cidade que você?",
    answer:
      "Não. O atendimento é on-line e pode ser realizado de qualquer lugar do Brasil, desde que você tenha acesso à internet e um ambiente reservado.",
  },
  {
    question: "Como funciona a primeira sessão?",
    answer:
      "É um momento de conversa para compreender o que motivou a busca por atendimento, conhecer sua história e identificar suas necessidades.",
  },
  {
    question: "Como faço para agendar?",
    answer:
      "Entre em contato pelo WhatsApp para consultar os horários disponíveis e receber as informações sobre o atendimento.",
  },
];

function scrollToSection(id: string) {
  document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeFaq, setActiveFaq] = useState<number | null>(0);
  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="site-shell">
      <header className="site-header">
        <a className="brand" href="#top" aria-label="Tamiris Lima - início">
          <span className="brand-logo-frame"><img className="brand-logo-image" src={logoUrl} alt="Logo circular de Tamiris Lima - Psicóloga Clínica" /></span>
          <span>
            <span className="brand-name">Tamiris <em>Lima</em></span>
            <span className="brand-credentials">Psicóloga Clínica | CRP 06/108808</span>
          </span>
        </a>

        <nav className={`desktop-nav ${menuOpen ? "is-open" : ""}`} aria-label="Navegação principal">
          <a href="#sobre" onClick={closeMenu}>Sobre mim</a>
          <a href="#cuidado" onClick={closeMenu}>Como posso ajudar</a>
          <a href="#funciona" onClick={closeMenu}>Como funciona</a>
          <a href="#duvidas" onClick={closeMenu}>Dúvidas</a>
          <a className="nav-cta" href={whatsappUrl} target="_blank" rel="noreferrer" onClick={closeMenu}>
            WhatsApp <ArrowUpRight size={15} />
          </a>
        </nav>

        <button
          className="menu-toggle"
          type="button"
          aria-label={menuOpen ? "Fechar menu" : "Abrir menu"}
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((open) => !open)}
        >
          {menuOpen ? <X size={23} /> : <Menu size={23} />}
        </button>
      </header>

      <main id="top">
        <section className="hero-section section-pad">
          <div className="hero-copy">
            <div className="hero-identity">
              <span className="hero-identity-name">TAMIRIS LIMA</span>
              <span>Psicóloga Clínica | CRP 06/108808</span>
            </div>
            <p className="eyebrow"><span className="eyebrow-line" /> PSICOTERAPIA ON-LINE PARA ADULTOS</p>
            <h1>Você cuida de tantas coisas. <span>E quem cuida de você?</span></h1>
            <p className="hero-lede">
              Um espaço de escuta e acolhimento para compreender suas emoções, cuidar da saúde emocional e olhar para si com mais atenção.
            </p>
            <p className="hero-location">Atendimento psicológico on-line para adultos em todo o Brasil.</p>
            <div className="hero-actions">
              <a className="button button-dark" href={whatsappUrl} target="_blank" rel="noreferrer">
                QUERO CONVERSAR <MoveRight size={17} />
              </a>
              <button className="text-link" type="button" onClick={() => scrollToSection("sobre")}>
                CONHEÇA MEU TRABALHO <ArrowDown size={16} />
              </button>
            </div>
            <div className="hero-note"><ShieldCheck size={16} /> Atendimento on-line, com sigilo e privacidade</div>
          </div>

          <div className="hero-visual">
            <div className="hero-orbit orbit-one" />
            <div className="hero-orbit orbit-two" />
            <div className="portrait-frame">
              <img src={portraitUrl} alt="Tamiris Lima, Psicóloga Clínica" />
              <div className="portrait-caption">
                <span>escuta</span><span className="caption-dot" /><span>acolhimento</span><span className="caption-dot" /><span>cuidado</span>
              </div>
            </div>
            <div className="hero-decoration">✳</div>
          </div>
        </section>

        <section className="intro-band" id="identificacao">
          <div className="container intro-grid">
            <p className="section-kicker">Você não precisa<br /><span>dar conta de tudo.</span></p>
            <div className="intro-text">
              <p>Pensamentos acelerados, ansiedade, autocobrança e cansaço emocional podem tornar a rotina mais difícil.</p>
              <p>Às vezes, você continua trabalhando, cumprindo compromissos e cuidando de tudo, mesmo quando emocionalmente sente que está no limite.</p>
              <p>A psicoterapia oferece um espaço para falar sobre o que está acontecendo, compreender seus sentimentos e construir novas possibilidades para lidar com as dificuldades.</p>
            </div>
            <div className="intro-side-note"><span className="side-note-mark">“</span><span>Um espaço de escuta<br />e acolhimento.</span></div>
          </div>
        </section>

        <section className="about-section section-pad" id="sobre">
          <div className="container about-grid">
            <div className="about-aside">
              <p className="eyebrow"><span className="eyebrow-line" /> Sobre mim</p>
              <div className="about-number">01<span>/</span>04</div>
              <div className="vertical-rule" />
              <p className="aside-small">Escuta, respeito<br />e acolhimento.</p>
            </div>
            <div className="about-content">
              <p className="section-kicker">Prazer, sou<br /><span>Tamiris Lima.</span></p>
              <div className="about-credentials">Psicóloga Clínica | CRP 06/108808</div>
              <div className="about-columns">
                <div>
                  <p className="lead-paragraph">Acredito na importância de um espaço terapêutico construído com escuta, respeito e acolhimento.</p>
                  <p>Meu trabalho é pautado no diálogo e na reflexão, considerando a história, as experiências e as necessidades de cada pessoa.</p>
                </div>
                <div>
                  <p>Com 14 anos de experiência na área clínica, busco oferecer um atendimento cuidadoso, ético e individualizado.</p>
                </div>
              </div>
              <a className="button button-outline" href={instagramUrl} target="_blank" rel="noreferrer">Conheça meu Instagram <Instagram size={17} /></a>
            </div>
          </div>
        </section>

        <section className="focus-section" id="cuidado">
          <div className="container">
            <div className="section-heading split-heading">
              <div>
                <p className="eyebrow"><span className="eyebrow-line" /> Como posso ajudar?</p>
                <h2>Um espaço para<br /><em>cuidar de você.</em></h2>
              </div>
              <p className="heading-side-copy">A psicoterapia é um espaço de escuta e acolhimento que pode ajudar você a compreender melhor suas emoções, refletir sobre suas experiências e lidar com diferentes dificuldades do dia a dia.</p>
            </div>
            <div className="focus-list">
              {focusAreas.map(({ number, title, text, icon: Icon }) => (
                <article className="focus-card" key={number}>
                  <span className="focus-number">{number}</span>
                  <div className="focus-icon"><Icon size={21} strokeWidth={1.45} /></div>
                  <div className="focus-card-copy"><h3>{title}</h3><p>{text}</p></div>
                  <ArrowUpRight className="focus-arrow" size={19} />
                </article>
              ))}
            </div>
            <p className="section-closing">Cada pessoa tem uma história e necessidades próprias. O processo terapêutico é construído de forma individualizada, respeitando o momento e as particularidades de cada pessoa.</p>
          </div>
        </section>

        <section className="process-section section-pad" id="funciona">
          <div className="container process-grid">
            <div className="process-intro">
              <p className="eyebrow"><span className="eyebrow-line" /> Como funciona a psicoterapia?</p>
              <h2>Cuidado psicológico<br /><em>no seu tempo e espaço.</em></h2>
              <p>Atendimento psicológico individual on-line.</p>
              <div className="process-symbol"><span>✦</span><span>✧</span><span>✦</span></div>
            </div>
            <div className="how-panel">
              <div className="how-detail"><Video size={20} /><div><strong>Público</strong><span>adultos.</span></div></div>
              <div className="how-detail"><Video size={20} /><div><strong>Modalidade</strong><span>videochamada.</span></div></div>
              <div className="how-detail"><Clock3 size={20} /><div><strong>Duração</strong><span>50 minutos.</span></div></div>
              <div className="how-detail"><CalendarDays size={20} /><div><strong>Frequência</strong><span>semanal ou quinzenal.</span></div></div>
              <div className="how-detail"><Globe2 size={20} /><div><strong>Localidade</strong><span>atendimento em todo o Brasil.</span></div></div>
              <div className="how-privacy"><ShieldCheck size={18} /><p>As sessões acontecem em ambiente reservado, preservando o sigilo e a privacidade do atendimento.</p></div>
            </div>
          </div>
          <div className="container process-cta-wrap">
            <a className="button button-dark" href={whatsappUrl} target="_blank" rel="noreferrer">CONSULTAR HORÁRIOS <Phone size={17} /></a>
          </div>
        </section>

        <section className="faq-section section-pad" id="duvidas">
          <div className="container faq-grid">
            <div className="faq-intro"><p className="eyebrow"><span className="eyebrow-line" /> Dúvidas frequentes</p><h2>Antes de<br /><em>começar.</em></h2><p>Entre em contato pelo WhatsApp para consultar os horários disponíveis e receber as informações sobre o atendimento.</p><a className="inline-link" href={whatsappUrl} target="_blank" rel="noreferrer">Falar pelo WhatsApp <ArrowUpRight size={16} /></a></div>
            <div className="faq-list">
              {faqs.map((faq, index) => <div className={`faq-item ${activeFaq === index ? "is-open" : ""}`} key={faq.question}><button type="button" aria-expanded={activeFaq === index} aria-controls={`faq-panel-${index}`} onClick={() => setActiveFaq(activeFaq === index ? null : index)}><span>{faq.question}</span><ChevronDown size={19} /></button>{activeFaq === index && <div className="faq-answer" id={`faq-panel-${index}`} role="region"><p>{faq.answer}</p></div>}</div>)}
            </div>
          </div>
        </section>

        <section className="final-cta-section" id="contato">
          <div className="cta-decoration cta-decoration-left">✳</div><div className="cta-decoration cta-decoration-right">✦</div>
          <div className="container final-cta-inner">
            <p className="eyebrow eyebrow-light"><span className="eyebrow-line" /> Cuidado psicológico</p>
            <h2>Olhar para si também<br /><em>é importante.</em></h2>
            <p>A psicoterapia pode ser um espaço para compreender o que você sente, refletir sobre suas experiências e cuidar da sua saúde emocional.</p>
            <p>Se deseja conhecer melhor o atendimento, entre em contato.</p>
            <a className="button button-light" href={whatsappUrl} target="_blank" rel="noreferrer"><Phone size={18} /> QUERO CONVERSAR PELO WHATSAPP <ArrowUpRight size={16} /></a>
            <span className="cta-note"><MessageCircle size={15} /> Atendimento psicológico on-line para adultos em todo o Brasil.</span>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="container footer-top"><a className="brand footer-brand" href="#top"><span className="brand-logo-frame"><img className="brand-logo-image" src={logoUrl} alt="Logo circular de Tamiris Lima - Psicóloga Clínica" /></span><span><span className="brand-name">Tamiris <em>Lima</em></span><span className="brand-credentials">Psicóloga Clínica | CRP 06/108808</span></span></a><p>Psicoterapia on-line para adultos</p><a href={instagramUrl} target="_blank" rel="noreferrer" className="footer-instagram"><Instagram size={17} /> @tamiris.psico</a></div>
        <div className="container footer-bottom"><span>Tamiris Lima</span><span>Psicóloga Clínica | CRP 06/108808</span><a href="#top">Voltar ao início <ArrowUpRight size={14} /></a></div>
      </footer>

      <a className="floating-whatsapp" href={whatsappUrl} target="_blank" rel="noreferrer" aria-label="Conversar pelo WhatsApp"><MessageCircle size={21} /></a>
      <a className="floating-instagram" href={instagramUrl} target="_blank" rel="noreferrer" aria-label="Abrir Instagram @tamiris.psico"><Instagram size={20} /></a>
    </div>
  );
}
