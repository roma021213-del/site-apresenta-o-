# Entregas

## Identidade e apresentação
- [x] Atualizar o site existente, preservando a estrutura funcional e aplicando uma apresentação elegante, acolhedora, minimalista e profissional.
- [x] Manter a identidade visual feminina, leve e profissional, com boa leitura em celular, tablet e computador.
- [x] Exibir TAMIRIS LIMA e Psicóloga Clínica | CRP 06/108808 na apresentação superior, no conteúdo Sobre mim e no rodapé.
- [x] Utilizar a fotografia profissional fornecida na primeira tela.

## Conteúdo profissional
- [x] Aplicar os textos fornecidos para a primeira tela, incluindo PSICOTERAPIA ON-LINE PARA ADULTOS, a pergunta principal, a apresentação do atendimento e a localidade em todo o Brasil.
- [x] Aplicar a seção Você não precisa dar conta de tudo com os três parágrafos fornecidos.
- [x] Aplicar a seção Prazer, sou Tamiris Lima com CRP, abordagem de trabalho e 14 anos de experiência na área clínica, sem acrescentar promessas de resultados.
- [x] Apresentar os cinco temas fornecidos: ansiedade e pensamentos acelerados; depressão e desânimo; procrastinação e autocobrança; autoestima e autoconhecimento; relacionamentos e limites.
- [x] Finalizar a seção de temas com o texto fornecido sobre história, necessidades próprias e processo individualizado.
- [x] Aplicar a seção Como funciona a psicoterapia com público, modalidade, duração, frequência, localidade e sigilo/privacidade.
- [x] Aplicar as três dúvidas frequentes e respostas fornecidas.
- [x] Aplicar a chamada final Olhar para si também é importante e o texto fornecido.

## Funcionalidade e contato
- [x] Usar o WhatsApp oficial https://wa.me/message/R7IFRNRFKHMND1 no botão principal, no botão Consultar horários, na chamada final e no botão flutuante visível.
- [x] Manter o Instagram @tamiris.psico clicável e direcionado ao perfil informado.
- [x] Garantir navegação por âncoras, FAQ expansível, menu responsivo e botões funcionais.
- [x] Garantir adaptação para celular, tablet e computador, evitando parágrafos longos e textos pequenos.
